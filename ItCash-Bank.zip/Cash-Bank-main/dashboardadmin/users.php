<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

checkSession();
if (!isAdmin()) {
    redirect('../login.php');
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_balance'])) {
    try {
        $accountId = $_POST['account_id'];
        $amount = floatval($_POST['amount']);
        $type = $_POST['transaction_type'];
        
        if ($amount <= 0) {
            throw new Exception("Amount must be greater than 0");
        }
        
        $pdo->beginTransaction();
        
        // Get current balance
        $stmt = $pdo->prepare("SELECT balance FROM accounts WHERE id = ? FOR UPDATE");
        $stmt->execute([$accountId]);
        $currentBalance = $stmt->fetchColumn();
        
        if ($currentBalance === false) {
            throw new Exception("Account not found");
        }
        
        // Calculate new balance
        $newBalance = $type === 'credit' ? $currentBalance + $amount : $currentBalance - $amount;
        
        if ($newBalance < 0) {
            throw new Exception("Insufficient funds");
        }
        
        // Update balance
        $stmt = $pdo->prepare("UPDATE accounts SET balance = ? WHERE id = ?");
        $stmt->execute([$newBalance, $accountId]);
        
        // Convertir le type pour la base de données
        $dbTransactionType = $type === 'credit' ? 'deposit' : 'withdrawal';
        
        // Record transaction
        $stmt = $pdo->prepare("
            INSERT INTO transactions (
                from_account_id, 
                to_account_id, 
                type, 
                amount, 
                status, 
                reference_number,
                description
            ) VALUES (?, ?, ?, ?, 'completed', ?, ?)
        ");
        
        $reference = 'ADM' . time() . rand(1000, 9999);
        $description = "Administrative {$type} by " . ($_SESSION['user_email'] ?? 'admin');
        
        $fromAccount = $type === 'debit' ? $accountId : null;
        $toAccount = $type === 'credit' ? $accountId : null;
        
        $stmt->execute([$fromAccount, $toAccount, $dbTransactionType, $amount, $reference, $description]);
        
        $pdo->commit();
        $message = "Balance updated successfully";
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    try {
        $userId = $_POST['user_id'];
        
        $pdo->beginTransaction();
        
        // Supprimer les tokens de réinitialisation de mot de passe
        $stmt = $pdo->prepare("DELETE FROM password_reset_tokens WHERE user_id = ?");
        $stmt->execute([$userId]);
        
        // Supprimer les demandes de carte
        $stmt = $pdo->prepare("DELETE FROM card_requests WHERE user_id = ?");
        $stmt->execute([$userId]);
        
        // Supprimer les transactions liées
        $stmt = $pdo->prepare("DELETE FROM transactions WHERE from_account_id IN (SELECT id FROM accounts WHERE user_id = ?) OR to_account_id IN (SELECT id FROM accounts WHERE user_id = ?)");
        $stmt->execute([$userId, $userId]);
        
        // Supprimer le compte
        $stmt = $pdo->prepare("DELETE FROM accounts WHERE user_id = ?");
        $stmt->execute([$userId]);
        
        // Supprimer l'utilisateur
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        
        $pdo->commit();
        $message = "User deleted successfully";
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Error deleting user: " . $e->getMessage();
    }
}

// Get users with their account details
$users = $pdo->query("
    SELECT u.*, a.id as account_id, a.account_number, a.balance, a.status as account_status
    FROM users u
    LEFT JOIN accounts a ON u.id = a.user_id
    WHERE u.role_id = 1
    ORDER BY u.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users - ITCash Bank Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <?php include 'includes/admin-header.php'; ?>
    
    <div class="container">
        <div class="admin-section">
            <h2>User Management</h2>
            
            <?php if (!empty($message)): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <a href="create-user.php" class="btn btn-primary">Add New User</a>
            
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Account Number</th>
                        <th>Balance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['account_number'] ?? 'No account'); ?></td>
                        <td>€<?php echo number_format($user['balance'] ?? 0, 2); ?></td>
                        <td><?php echo htmlspecialchars($user['account_status'] ?? 'N/A'); ?></td>
                        <td>
                            <?php if ($user['account_id']): ?>
                            <button onclick="showBalanceModal(<?php echo $user['account_id']; ?>)" class="btn btn-primary">
                                Manage Balance
                            </button>
                            <?php endif; ?>
                            <button onclick="deleteUser(<?php echo $user['id']; ?>)" class="btn btn-danger">
                                Delete
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Balance Management Modal -->
            <div id="balanceModal" class="modal" style="display: none;">
                <div class="modal-content">
                    <h3>Update Account Balance</h3>
                    <form method="POST" id="balanceForm">
                        <input type="hidden" name="account_id" id="modalAccountId">
                        <div class="form-group">
                            <label>Transaction Type:</label>
                            <select name="transaction_type" required>
                                <option value="credit">Credit (Add Money)</option>
                                <option value="debit">Debit (Remove Money)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Amount:</label>
                            <input type="number" name="amount" step="0.01" min="0.01" required>
                        </div>
                        <div class="button-container">
                            <button type="submit" name="update_balance" class="btn btn-primary">Update Balance</button>
                            <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <script>
            function showBalanceModal(accountId) {
                document.getElementById('modalAccountId').value = accountId;
                document.getElementById('balanceModal').style.display = 'block';
            }
            
            function closeModal() {
                document.getElementById('balanceModal').style.display = 'none';
            }
            
            function deleteUser(userId) {
                if (confirm('Are you sure you want to delete this user?')) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.style.display = 'none';
                    
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'user_id';
                    input.value = userId;
                    
                    const submitBtn = document.createElement('input');
                    submitBtn.type = 'hidden';
                    submitBtn.name = 'delete_user';
                    
                    form.appendChild(input);
                    form.appendChild(submitBtn);
                    document.body.appendChild(form);
                    
                    form.submit();
                }
            }
            </script>
        </div>
    </div>
</body>
</html>
