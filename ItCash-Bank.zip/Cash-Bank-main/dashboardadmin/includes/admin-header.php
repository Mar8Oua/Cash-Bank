<div class="admin-header">
    <div class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="users.php">Users</a>
        <a href="card-requests.php">Card Requests</a>
        <a href="transactions.php">Transactions</a>
        <a href="banking-services.php">Banking Services</a>
    </div>
    <div class="admin-user">
        <span>Welcome, <?php echo htmlspecialchars($_SESSION['user_email']); ?></span>
        <a href="/Cash-Bank-main/logout.php" class="btn btn-secondary">Logout</a>
    </div>
</div>
