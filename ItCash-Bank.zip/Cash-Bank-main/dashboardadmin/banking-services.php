<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

checkSession();
if (!isAdmin()) {
    redirect('../login.php');
}

$message = '';
$error = '';

// Check if banking_services table exists
try {
    $pdo->query("SELECT 1 FROM banking_services LIMIT 1");
} catch(PDOException $e) {
    // Create banking_services table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS banking_services (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            type ENUM('loan', 'investment', 'insurance', 'other') NOT NULL,
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Create loan_offers table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS loan_offers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT,
            interest_rate DECIMAL(5,2) NOT NULL,
            min_amount DECIMAL(15,2) NOT NULL,
            max_amount DECIMAL(15,2) NOT NULL,
            duration_months INT NOT NULL,
            FOREIGN KEY (service_id) REFERENCES banking_services(id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $type = $_POST['type'] ?? '';
    
    if (!empty($name) && !empty($type)) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("
                INSERT INTO banking_services (name, description, type, created_by)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$name, $description, $type, $_SESSION['user_id']]);
            
            if ($type === 'loan') {
                $serviceId = $pdo->lastInsertId();
                $stmt = $pdo->prepare("
                    INSERT INTO loan_offers (
                        service_id, interest_rate, min_amount, max_amount, duration_months
                    ) VALUES (?, ?, ?, ?, 12)
                ");
                $stmt->execute([
                    $serviceId,
                    floatval($_POST['interest_rate'] ?? 0),
                    floatval($_POST['min_amount'] ?? 0),
                    floatval($_POST['max_amount'] ?? 0)
                ]);
            }
            
            $pdo->commit();
            $message = "Service added successfully!";
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}

// Get services list with error handling
try {
    $services = $pdo->query("
        SELECT bs.*, u.email as created_by_email
        FROM banking_services bs
        LEFT JOIN users u ON bs.created_by = u.id
        ORDER BY bs.created_at DESC
    ")->fetchAll();
} catch(PDOException $e) {
    $services = [];
    $error = "Error loading services.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Banking Services - ITCash Bank Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <?php include 'includes/admin-header.php'; ?>
    
    <div class="container">
        <div class="admin-section">
            <h2>Banking Services Management</h2>
            
            <?php if ($message): ?>
                <div class="message"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- Service Creation Form -->
            <form method="POST" class="service-form" id="serviceForm">
                <div class="form-group">
                    <label>Service Name:</label>
                    <input type="text" name="name" required>
                </div>
                
                <div class="form-group">
                    <label>Type:</label>
                    <select name="type" id="serviceType" required>
                        <option value="">Select Type</option>
                        <option value="loan">Loan</option>
                        <option value="investment">Investment</option>
                        <option value="insurance">Insurance</option>
                    </select>
                </div>

                <div id="loanDetails" style="display: none;">
                    <div class="form-group">
                        <label>Interest Rate (%):</label>
                        <input type="number" name="interest_rate" step="0.01" min="0">
                    </div>
                    <div class="form-group">
                        <label>Minimum Amount:</label>
                        <input type="number" name="min_amount" min="0">
                    </div>
                    <div class="form-group">
                        <label>Maximum Amount:</label>
                        <input type="number" name="max_amount" min="0">
                    </div>
                </div>

                <div class="form-group">
                    <label>Description:</label>
                    <textarea name="description" required></textarea>
                </div>

                <div class="button-container">
                    <button type="submit" class="btn btn-primary">Add Service</button>
                </div>
            </form>

            <!-- Services List -->
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Details</th>
                        <th>Status</th>
                        <th>Created By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $service): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($service['name']); ?></td>
                        <td><?php echo htmlspecialchars($service['type']); ?></td>
                        <td>
                            <?php if ($service['type'] === 'loan' && $service['interest_rate']): ?>
                                Rate: <?php echo number_format($service['interest_rate'], 2); ?>%<br>
                                Range: €<?php echo number_format($service['min_amount']); ?> - 
                                      €<?php echo number_format($service['max_amount']); ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($service['status']); ?></td>
                        <td><?php echo htmlspecialchars($service['created_by_email']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    document.getElementById('serviceType').addEventListener('change', function() {
        const loanDetails = document.getElementById('loanDetails');
        loanDetails.style.display = this.value === 'loan' ? 'block' : 'none';
    });
    </script>
</body>
</html>
