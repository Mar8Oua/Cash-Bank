<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

checkSession();
if (!isAdmin()) {
    redirect('../login.php');
}

$requests = $pdo->query("
    SELECT cr.*, 
           CONCAT(u.first_name, ' ', u.last_name) as user_name,
           u.email
    FROM card_requests cr
    JOIN users u ON cr.user_id = u.id
    WHERE cr.status = 'pending'
    ORDER BY cr.created_at DESC
")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestId = $_POST['request_id'] ?? null;
    $action = $_POST['action'] ?? null;
    
    if ($requestId && $action) {
        try {
            $pdo->beginTransaction();

            // Get request details
            $stmt = $pdo->prepare("SELECT * FROM card_requests WHERE id = ?");
            $stmt->execute([$requestId]);
            $request = $stmt->fetch();

            // Update request status
            $stmt = $pdo->prepare("
                UPDATE card_requests 
                SET status = ?, processed_by = ? 
                WHERE id = ?
            ");
            $stmt->execute([$action, $_SESSION['user_id'], $requestId]);

            // If approved, create new card
            if ($action === 'approved') {
                // Generate card details
                $cardNumber = date('Y') . str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT) . str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
                $cvv = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
                $pin = password_hash(str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT), PASSWORD_DEFAULT);
                $expirationDate = date('Y-m-d', strtotime('+3 years'));

                // Create card
                $stmt = $pdo->prepare("
                    INSERT INTO cards (
                        user_id,
                        card_number,
                        card_type,
                        expiration_date,
                        cvv,
                        pin,
                        status,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())
                ");
                $stmt->execute([
                    $request['user_id'],
                    $cardNumber,
                    $request['card_type'],
                    $expirationDate,
                    $cvv,
                    $pin
                ]);

                // Create notification for user
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (
                        user_id,
                        title,
                        message,
                        type
                    ) VALUES (?, ?, ?, 'success')
                ");
                $stmt->execute([
                    $request['user_id'],
                    'Card Request Approved',
                    'Your ' . ucfirst($request['card_type']) . ' card request has been approved. Your card will be delivered soon.'
                ]);
            }

            $pdo->commit();
            header('Location: card-requests.php');
            exit;
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Card Requests - ITCash Bank Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <?php include 'includes/admin-header.php'; ?>
    
    <div class="container">
        <div class="admin-section">
            <h2>Card Request Management</h2>
            
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>User</th>
                        <th>Card Type</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $req): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(date('Y-m-d', strtotime($req['created_at']))); ?></td>
                        <td><?php echo htmlspecialchars($req['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($req['card_type']); ?></td>
                        <td>
                            <form method="POST" style="display:inline">
                                <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                <button type="submit" name="action" value="approved" class="btn btn-primary">Approve</button>
                                <button type="submit" name="action" value="rejected" class="btn btn-secondary">Reject</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
