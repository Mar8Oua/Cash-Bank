<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

checkSession();
if (!isAdmin()) {
    redirect('../login.php');
}

$transactions = $pdo->query("
    SELECT 
        t.*,
        fa.account_number as from_account,
        ta.account_number as to_account,
        CONCAT(u.first_name, ' ', u.last_name) as user_name
    FROM transactions t
    LEFT JOIN accounts fa ON t.from_account_id = fa.id
    LEFT JOIN accounts ta ON t.to_account_id = ta.id
    LEFT JOIN users u ON fa.user_id = u.id
    ORDER BY t.created_at DESC
    LIMIT 100
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transactions - ITCash Bank Admin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <?php include 'includes/admin-header.php'; ?>
    
    <div class="container">
        <div class="admin-section">
            <h2>Transaction Management</h2>
            
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $trans): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(date('Y-m-d H:i', strtotime($trans['created_at']))); ?></td>
                        <td><?php echo htmlspecialchars($trans['type']); ?></td>
                        <td><?php echo htmlspecialchars($trans['from_account'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($trans['to_account'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars(number_format($trans['amount'], 2)); ?></td>
                        <td><?php echo htmlspecialchars($trans['status']); ?></td>
                        <td>
                            <a href="view-transaction.php?id=<?php echo $trans['id']; ?>" class="btn btn-secondary">View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
