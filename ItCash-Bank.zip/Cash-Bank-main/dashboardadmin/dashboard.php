<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Vérification de session et admin
checkSession();
if (!isAdmin()) {
    redirect('../login.php');
}

// Get dashboard statistics
$stats = [
    'users' => $pdo->query("SELECT COUNT(*) FROM users WHERE role_id = 1")->fetchColumn(),
    'pending_cards' => $pdo->query("SELECT COUNT(*) FROM card_requests WHERE status = 'pending'")->fetchColumn(),
    'transactions' => $pdo->query("SELECT COUNT(*) FROM transactions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetchColumn()
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - ITCash Bank</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <?php include 'includes/admin-header.php'; ?>
    
    <div class="container">
        <div class="admin-dashboard">
            <h2>Administration Dashboard</h2>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Users</h3>
                    <p class="stat-number"><?php echo $stats['users']; ?></p>
                    <a href="users.php" class="btn btn-primary">Manage Users</a>
                </div>
                
                <div class="stat-card">
                    <h3>Pending Card Requests</h3>
                    <p class="stat-number"><?php echo $stats['pending_cards']; ?></p>
                    <a href="card-requests.php" class="btn btn-primary">View Requests</a>
                </div>
                
                <div class="stat-card">
                    <h3>24h Transactions</h3>
                    <p class="stat-number"><?php echo $stats['transactions']; ?></p>
                    <a href="transactions.php" class="btn btn-primary">View Transactions</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
