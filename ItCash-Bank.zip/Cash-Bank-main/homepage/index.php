<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ITCash Bank</title>
    <link rel="stylesheet" href="index.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    
        <header>
            <div class="logo"><img src="images/e5acd42e-a154-4327-84ea-56cf1d947f8a_removalai_preview 1.png" alt="ITCash Bank Logo"></div>
           <ul class="list1" >
            <li><a href="">Home</a></li>
            <li><a href="#features">Features</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="">Help</a></li>
           </ul> 
           <div class="list2">
              <button class="but1"><a href="../login/login.php">Log in</a></button>
              <button class="but2"><a href="">Start for free</a></button>
           </div>
           <!-- Removed the menu icon -->
         </header>
        <div class="container">
             <div>
             <h3>Contrary to popular belief, Lorem Ipsum is not simply random text.</h3>
             <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary</p>
            </div>
             <div class="search">
                <span class=" icon material-symbols-outlined">search</span>
                <input class="search2" type="text" placeholder="Please enter to search">
                <button><a href="">Search</a></button>
             </div>
             <div class="info">
               <div class="in">
                  <p>8347</p>
                  <p>Visitor Everyday</p>
               </div>
               <div class="in">
                  <p>$3M+</p>
                  <p>Transaction Completed</p>
              </div> 
             </div>
        </div>
        
        <!-- Services Section -->
        <section id="services" class="services-section">
            <div class="section-header">
                <h2>Our Services</h2>
                <p>Discover the wide range of banking solutions we offer</p>
            </div>
            <div class="services-container">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-money-check-alt"></i>
                    </div>
                    <h3>Checking Accounts</h3>
                    <p>Manage your daily finances with ease and convenience.</p>
                    <a href="#" class="service-link">Learn More</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-piggy-bank"></i>
                    </div>
                    <h3>Savings Accounts</h3>
                    <p>Grow your money with competitive interest rates.</p>
                    <a href="#" class="service-link">Learn More</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <h3>Credit Cards</h3>
                    <p>Enjoy rewards, cashback, and special financing options.</p>
                    <a href="#" class="service-link">Learn More</a>
                </div>
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <h3>Mortgage Loans</h3>
                    <p>Find the perfect financing solution for your dream home.</p>
                    <a href="#" class="service-link">Learn More</a>
                </div>
            </div>
        </section>
        
        <!-- Features Section -->
        <section id="features" class="features-section">
            <div class="section-header">
                <h2>Key Features</h2>
                <p>Why choose ITCash Bank for your financial needs</p>
            </div>
            <div class="features-container">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Secure Banking</h3>
                        <p>Advanced encryption and security protocols to protect your financial data.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Mobile Banking</h3>
                        <p>Manage your accounts anytime, anywhere with our user-friendly mobile app.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="feature-content">
                        <h3>24/7 Support</h3>
                        <p>Our dedicated support team is available round the clock to assist you.</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Competitive Rates</h3>
                        <p>Enjoy some of the best interest rates and lowest fees in the industry.</p>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Footer -->
        <footer class="footer">
            <div class="footer-container">
                <div class="footer-column">
                    <h3>ITCash Bank</h3>
                    <p>Your trusted financial partner for a secure and prosperous future.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="footer-column">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#features">Features</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Services</h4>
                    <ul>
                        <li><a href="#">Personal Banking</a></li>
                        <li><a href="#">Business Banking</a></li>
                        <li><a href="#">Loans & Mortgages</a></li>
                        <li><a href="#">Investment Solutions</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Contact Us</h4>
                    <p><i class="fas fa-map-marker-alt"></i> 123 itc Street, Blida 1 City</p>
                    <p><i class="fas fa-phone"></i> +1 (555) 123-4567</p>
                    <p><i class="fas fa-envelope"></i> info@itcashbank.com</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 ITCash Bank. All rights reserved.</p>
            </div>
        </footer>
        
</body>
</html>