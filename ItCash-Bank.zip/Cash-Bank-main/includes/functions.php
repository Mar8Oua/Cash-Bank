<?php
function checkSession() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /Cash-Bank-main/login/login.php");
        exit();
    }
}

function isAdmin() {
    return isset($_SESSION['role_id']) && $_SESSION['role_id'] == 2;
}

function redirect($path) {
    header("Location: $path");
    exit();
}

function createUser($email, $firstName, $lastName, $phone = null, $address = null) {
    global $pdo;
    
    try {
        // Vérifier si l'email existe déjà
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetchColumn()) {
            return ['success' => false, 'error' => 'Email already exists'];
        }
        
        $pdo->beginTransaction();
        
        // Générer un mot de passe temporaire
        $tempPassword = generateRandomPassword();
        $hashedPassword = password_hash($tempPassword, PASSWORD_DEFAULT);
        
        // Insérer l'utilisateur
        $stmt = $pdo->prepare("
            INSERT INTO users (email, password, first_name, last_name, phone, address, role_id)
            VALUES (?, ?, ?, ?, ?, ?, 1)
        ");
        $stmt->execute([$email, $hashedPassword, $firstName, $lastName, $phone, $address]);
        
        $userId = $pdo->lastInsertId();
        
        // Créer un compte bancaire pour l'utilisateur
        $accountNumber = generateAccountNumber();
        $stmt = $pdo->prepare("
            INSERT INTO accounts (user_id, account_number, balance, status)
            VALUES (?, ?, 0, 'active')
        ");
        $stmt->execute([$userId, $accountNumber]);
        
        $pdo->commit();
        return ['success' => true, 'password' => $tempPassword];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

function generateAccountNumber() {
    return 'ACC' . date('Y') . rand(100000, 999999);
}
?>
