<?php
session_start();
require_once '../db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];
    
    try {
        $first_name = filter_var($_POST['first_name'], FILTER_SANITIZE_STRING);
        $last_name = filter_var($_POST['last_name'], FILTER_SANITIZE_STRING);
        $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
        $address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);
        
        $stmt = $pdo->prepare("
            UPDATE users 
            SET first_name = ?, 
                last_name = ?, 
                phone = ?, 
                address = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        
        $stmt->execute([$first_name, $last_name, $phone, $address, $_SESSION['user_id']]);
        
        $response['success'] = true;
        $response['message'] = 'Profile updated successfully';
        
    } catch (Exception $e) {
        $response['message'] = 'An error occurred while updating your profile';
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
