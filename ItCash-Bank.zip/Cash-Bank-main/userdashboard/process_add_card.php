<?php
session_start();
require_once '../db_connection.php';

if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Not authenticated']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO cards (user_id, card_number, card_type, expiration_date, cvv, pin, status)
            VALUES (?, ?, ?, ?, ?, ?, 'active')
        ");

        $expDate = date('Y-m-d', strtotime('+3 years'));
        $cardNumber = generateCardNumber();
        $cvv = generateCVV();
        $pin = password_hash($_POST['pin'], PASSWORD_DEFAULT);

        $result = $stmt->execute([
            $_SESSION['user_id'],
            $cardNumber,
            $_POST['cardType'],
            $expDate,
            $cvv,
            $pin
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Card added successfully'
        ]);
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
}

function generateCardNumber() {
    return rand(1000, 9999) . rand(1000, 9999) . rand(1000, 9999) . rand(1000, 9999);
}

function generateCVV() {
    return rand(100, 999);
}
