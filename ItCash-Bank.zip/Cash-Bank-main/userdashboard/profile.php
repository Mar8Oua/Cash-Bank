<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login/login.php');
    exit();
}

require_once '../db_connection.php';

// Get user data
$stmt = $pdo->prepare("SELECT email, first_name, last_name, phone, address FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - ITCash Bank</title>
    <link rel="stylesheet" href="dash.css">
    <style>
        .profile-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .profile-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .profile-title {
            font-size: 24px;
            color: #172B85;
            font-weight: bold;
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #E0E0E0;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: #172B85;
            outline: none;
        }
        .save-btn {
            background: #172B85;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s;
        }
        .save-btn:hover {
            background: #1e3aa3;
        }
        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            display: none;
        }
        .success-message {
            background: #e8f5e9;
            color: #2e7d32;
        }
        .error-message {
            background: #ffebee;
            color: #c62828;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo"><img src="./e5acd42e-a154-4327-84ea-56cf1d947f8a_removalai_preview 1.png" alt=""></div>
            <div class="sidebar-menu">
                <div class="menu-item" onclick="window.location.href='Dash.php'">
                    <i class="fas fa-th-large"></i>
                    <span>Dashboard</span>
                </div>
                <div class="menu-item" onclick="window.location.href='mycard.php'">
                    <i class="far fa-credit-card"></i>
                    <span>my card</span>
                </div>
                <div class="menu-item">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Payement</span>
                </div>
                <div class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>My bills</span>
                </div>
                <div class="menu-item">
                    <i class="fas fa-shield-alt"></i>
                    <span>Security</span>
                </div>
                <div class="menu-item active">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </div>
            </div>
            <div class="sidebar-footer">
                <div class="help-section">
                    <i class="far fa-question-circle"></i>
                    <span>Get Help</span>
                </div>
                <div class="logout-section" style="margin-top: 20px; cursor: pointer;" onclick="window.location.href='../login/logout.php'">
                    <i class="fas fa-sign-out-alt" style="color: #ff4757;"></i>
                    <span style="color: #ff4757;">Logout</span>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search or type">
                </div>
                <!-- ...existing header icons... -->
            </div>

            <!-- Profile Content -->
            <div class="profile-content">
                <div class="profile-header">
                    <div class="profile-title">Profile Settings</div>
                </div>
                
                <div class="message success-message" id="successMessage"></div>
                <div class="message error-message" id="errorMessage"></div>

                <form id="profileForm">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo htmlspecialchars($user['address']); ?>">
                    </div>
                    <button type="submit" class="save-btn">Save Changes</button>
                </form>

                <!-- Password Change Section -->
                <div class="profile-header" style="margin-top: 40px;">
                    <div class="profile-title">Change Password</div>
                </div>
                <form id="passwordForm">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" required minlength="8">
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required minlength="8">
                    </div>
                    <div class="message error-message" id="passwordError"></div>
                    <div class="message success-message" id="passwordSuccess"></div>
                    <button type="submit" class="save-btn">Change Password</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Font Awesome for Icons -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    
    <script>
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('update_profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('successMessage').textContent = 'Profile updated successfully!';
                    document.getElementById('successMessage').style.display = 'block';
                    document.getElementById('errorMessage').style.display = 'none';
                } else {
                    document.getElementById('errorMessage').textContent = data.message;
                    document.getElementById('errorMessage').style.display = 'block';
                    document.getElementById('successMessage').style.display = 'none';
                }
            })
            .catch(error => {
                document.getElementById('errorMessage').textContent = 'An error occurred. Please try again.';
                document.getElementById('errorMessage').style.display = 'block';
                document.getElementById('successMessage').style.display = 'none';
            });
        });

        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            if (formData.get('new_password') !== formData.get('confirm_password')) {
                document.getElementById('passwordError').textContent = 'New passwords do not match';
                document.getElementById('passwordError').style.display = 'block';
                document.getElementById('passwordSuccess').style.display = 'none';
                return;
            }
            
            fetch('update_password.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('passwordSuccess').textContent = data.message;
                    document.getElementById('passwordSuccess').style.display = 'block';
                    document.getElementById('passwordError').style.display = 'none';
                    this.reset();
                } else {
                    document.getElementById('passwordError').textContent = data.message;
                    document.getElementById('passwordError').style.display = 'block';
                    document.getElementById('passwordSuccess').style.display = 'none';
                }
            })
            .catch(error => {
                document.getElementById('passwordError').textContent = 'An error occurred. Please try again.';
                document.getElementById('passwordError').style.display = 'block';
                document.getElementById('passwordSuccess').style.display = 'none';
            });
        });
    </script>
</body>
</html>
