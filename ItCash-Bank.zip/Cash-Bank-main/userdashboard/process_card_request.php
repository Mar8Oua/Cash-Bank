<?php
session_start();
require_once '../db_connection.php';

if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Not authenticated']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Vérifier si l'utilisateur a déjà une demande en cours
        $checkStmt = $pdo->prepare("
            SELECT COUNT(*) FROM card_requests 
            WHERE user_id = ? AND status = 'pending'
        ");
        $checkStmt->execute([$_SESSION['user_id']]);
        
        if ($checkStmt->fetchColumn() > 0) {
            die(json_encode([
                'success' => false, 
                'message' => 'You already have a pending card request'
            ]));
        }

        // Insérer la nouvelle demande
        $stmt = $pdo->prepare("
            INSERT INTO card_requests (user_id, card_type, status, reason) 
            VALUES (?, ?, 'pending', ?)
        ");

        $result = $stmt->execute([
            $_SESSION['user_id'],
            $_POST['cardType'],
            $_POST['reason']
        ]);

        if ($result) {
            // Notifier l'admin
            $adminStmt = $pdo->prepare("
                INSERT INTO notifications (user_id, title, message, type) 
                SELECT id, 'New Card Request', 'A new card request requires your approval', 'alert'
                FROM users WHERE role_id = 2
            ");
            $adminStmt->execute();

            echo json_encode([
                'success' => true,
                'message' => 'Your card request has been submitted'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to submit request'
            ]);
        }
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error'
        ]);
    }
}
