<?php
session_start();
require_once '../db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];
    
    try {
        $amount = filter_var($_POST['amount'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $recipient = filter_var($_POST['recipient'], FILTER_SANITIZE_EMAIL);
        
        // Get sender's account
        $stmt = $pdo->prepare("SELECT id, balance FROM accounts WHERE user_id = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $sender_account = $stmt->fetch();
        
        if (!$sender_account || $sender_account['balance'] < $amount) {
            throw new Exception('Insufficient funds');
        }
        
        // Get recipient's account
        $stmt = $pdo->prepare("
            SELECT a.id, a.user_id 
            FROM accounts a 
            JOIN users u ON a.user_id = u.id 
            WHERE u.email = ? AND a.status = 'active' 
            LIMIT 1
        ");
        $stmt->execute([$recipient]);
        $recipient_account = $stmt->fetch();
        
        if (!$recipient_account) {
            throw new Exception('Recipient not found');
        }
        
        // Begin transaction
        $pdo->beginTransaction();
        
        // Deduct from sender
        $stmt = $pdo->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$amount, $sender_account['id']]);
        
        // Add to recipient
        $stmt = $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $recipient_account['id']]);
        
        // Record transaction
        $stmt = $pdo->prepare("
            INSERT INTO transactions (from_account_id, to_account_id, type, amount, status, reference_number) 
            VALUES (?, ?, 'transfer', ?, 'completed', ?)
        ");
        $reference = 'TRF' . time();
        $stmt->execute([$sender_account['id'], $recipient_account['id'], $amount, $reference]);
        
        $pdo->commit();
        $response['success'] = true;
        $response['message'] = 'Transfer successful';
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
