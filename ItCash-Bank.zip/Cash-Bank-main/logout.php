<?php
session_start();
session_destroy();
header("Location: /Cash-Bank-main/login/login.php");
exit();
